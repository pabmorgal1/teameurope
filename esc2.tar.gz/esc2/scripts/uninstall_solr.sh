#!/bin/bash
###############
# Descripcion
# Sintaxis:
# uninstall_solr.sh   
#
################
su solr -c "/opt/solr/bin/solr stop"
rm solr-7.5.0.tgz

if [ -d solr-7.5.0 ]; then
    rm -Rf solr-7.5.0
    rm install_solr_service.sh
else
    echo "Fichero no encontrado para borrar\n"
fi

if [ -d /opt/solr ]; then
    rm /opt/solr
else
    echo "/opt/solr no existe"
fi
if [ -d /opt/solr-7.5.0/ ]; then
    rm -Rf /opt/solr-7.5.0/
else
    echo "/opt/solr-7.5.0/ no existe\n"
fi

rm /etc/init.d/solr
rm /etc/default/solr.in.sh
rm -Rf /var/solr
