su solr -c "bin/solr start"
#su solr -c ".path/bin/solr start"
su solr -c "bin/solr create -c iTunes" #Crear core	
#su solr -c "path/bin/solr stop"

