##################
######BANANA######
##################
cd /opt/solr/server/solr-webapp/webapp
git clone https://github.com/lucidworks/banana
cd /opt/solr/server/solr-webapp/webapp/banana

cd /opt/solr/server/contexts
touch banana-jetty-contexts.xml; emacs banana-jetty-contexts.xml
##PEGAMOS EN EL XML:
<?xml version="1.0"?>
<!DOCTYPE Configure PUBLIC "-//Jetty//Configure//EN" "http://www.eclipse.org/jetty/configure_9_0.dtd">
<Configure class="org.eclipse.jetty.webapp.WebAppContext">
  <Set name="contextPath"><Property name="hostContext" default="/solr/banana"/></Set>
  <Set name="war"><Property name="jetty.base"/>/solr-webapp/webapp/banana</Set>
  <Set name="defaultsDescriptor"><Property name="jetty.base"/>/etc/webdefault.xml</Set>
  <Set name="extractWAR">false</Set>
</Configure>

su - solr -c "/opt/solr/bin/solr restart"
http://localhost:8983/solr/banana/src/#/dashboard























	

