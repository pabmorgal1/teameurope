#!/bin/bash
###############
# Descripcion
# Sintaxis:
# install_solr.sh   
#
################
wget http://ftp.cixug.es/apache/lucene/solr/7.5.0/solr-7.5.0.tgz
#if [ -f solr-7.5.0.tgz ]; then
#    tar zxf solr-7.5.0.tgz
#else
#    echo "Fichero no encontrado\n"
#fi

#Para ponerlo como servicio:
if [ -f solr-7.5.0.tgz ]; then
    tar zxf solr-7.5.0.tgz solr-7.5.0/bin/install_solr_service.sh --strip-components=2
    ./install_solr_service.sh solr-7.5.0.tgz 
    service solr stop
else
    echo "Fichero no existe\n"
fi

if [ -d /opt/solr ]; then
    chown -R solr /opt/solr
else
    echo "/opt/solr no existe\n"
fi
if [ -d /opt/solr-7.5.0/ ]; then
    chown -R solr /opt/solr-7.5.0/
else
    echo "/opt/solr-7.5.0/ no existe\n"
fi


