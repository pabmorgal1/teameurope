[root@192 ~]# cp -r /home/dit/Solr/esc1/ligaesp/ /opt/solr/server/solr/configsets/
[root@192 ~]# su - solr -c "/opt/solr/bin/solr create -c ligaesp -d /opt/solr/server/solr/configsets/ligaesp"
INFO  - 2019-01-02 13:11:40.287; org.apache.solr.util.configuration.SSLCredentialProviderFactory; Processing SSL Credential Provider chain: env;sysprop

Created new core 'ligaesp'
[root@192 ~]# /opt/solr/bin/post -c ligaesp /home/dit/Solr/esc1/teameurope/ligadef.json 
java -classpath /opt/solr/dist/solr-core-7.5.0.jar -Dauto=yes -Dc=ligaesp -Ddata=files org.apache.solr.util.SimplePostTool /home/dit/Solr/esc1/teameurope/ligadef.json
SimplePostTool version 5.0.0
Posting files to [base] url http://localhost:8983/solr/ligaesp/update...
Entering auto mode. File endings considered are xml,json,jsonl,csv,pdf,doc,docx,ppt,pptx,xls,xlsx,odt,odp,ods,ott,otp,ots,rtf,htm,html,txt,log
POSTing file ligadef.json (application/json) to [base]/json/docs
1 files indexed.
COMMITting Solr index changes to http://localhost:8983/solr/ligaesp/update...
Time spent: 0:00:01.609


-entrenador:"Abelardo Fernandez" --> TODOS LOS QUE NO SEA ENTRENADOR ABELARDO FERNANDEZ
entrenador:J* --> TODOS LOS QUE EMPIEZAN POR J
entrenador:*a* --> TODOS LOS QUE CONTIENEN UNA a
entrenador:abe~0.1* --> TODOS LOS QUE SE PARECEN QUE EMPIEZAN POR abe
&fq=lim_salarial:[200.000 TO *] --> EN FACET SETTING (LIM_SALARIAL)
ciudad:vitoria --> NO DIFERENCIA ENTRE MAYUSCULAS Y MINUSCULAS.
jugadores:"carlos vIGARAY" --> ME DEVUELVE EL EQUIPO DONDE JUEGA CARLOS VIGARAY
=====> EN INTERFAZ SELECCIONAR "FILTER BY ciudad sevilla"



